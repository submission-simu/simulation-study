rm(list = ls())
library("parallel")
library("xtable")
MC_repli <- 500

simulation <- function(iter){
  my_simulation_procedure <- function(iter){
    library("mvtnorm")
    library("MASS")
    library("survival")
    library("pracma")
    
    set.seed(iter)
    
    K <- 50
    cov_dim <- 6
    rho <- 0.5
    
    true_beta <- c(0.35, -0.65, 0.35, 0.16, -0.14, -0.6)
    site_size <- rep(200, K)#c(200, rep(100, K - 1))#rep(200, K)#c(50, rep(20, K - 1))#c(100, rep(50, K - 1))
    
    lower_a <- rep(-5, cov_dim)
    upper_b <- rep(5, cov_dim)
    
    mean_vec <- c(0.9, 0.25, 0.15, 0.25, 0.3, 0.1)#event rate: 0.8~0.13
    
    
    corr_mat <- matrix(rho, nrow = 6, ncol = 6)
    diag(corr_mat) <- 1
    
    generate_bernoulli <- function(n, mean_vector, corr_matrix) {
      cov_dim <- length(mean_vector)
      # Step 1: Generate multivariate normal samples
      mvn_samples <- mvrnorm(n, mu = rep(0, cov_dim), Sigma = corr_matrix)
      
      # Step 2: Convert to uniform using the standard normal CDF
      uniform_samples <- pnorm(mvn_samples)
      
      # Step 3: Transform to Bernoulli using the mean vector
      bernoulli_samples <- sapply(1:cov_dim, function(i) {
        uniform_samples[, i] < mean_vector[i]
      })
      
      return(1 * bernoulli_samples)
    }
    
    data.generation <- function(K, site_size, cov_dim, beta_star){
      
      n_cum <- c(0, cumsum(site_size))
      shape_seq <- seq(2.5, 1.5, length.out = K)
      scale_seq <- seq(8, 10, length.out = K)
      censor_low <- rep(0, K)
      censor_high <- rep(4.5, K)#V4 to V7 is 
      data_list <- as.list(rep(NA, K))
      
      for(k in 1:K){
        covariate_mat <- generate_bernoulli(n = site_size[k], mean_vector = mean_vec, corr_matrix = corr_mat)
        hazard_scaling <- c(covariate_mat %*% beta_star)
        baseline_t2e <- rweibull(site_size[k], shape = shape_seq[k], scale = scale_seq[k])
        Cox_t2e <- baseline_t2e * exp(-hazard_scaling / shape_seq[k])
        censor <- runif(site_size[k], min = censor_low[k], max = censor_high[k])
        
        local_data <- cbind(n_cum[k] + c(1:site_size[k]), 
                            rep(k, site_size[k]), 
                            pmin(Cox_t2e, censor), 
                            as.numeric(Cox_t2e <= censor), 
                            covariate_mat)
        
        local_data <- as.data.frame(local_data)
        names(local_data) <- c("ID", "site", "t2e", "censor_ind", paste("V", 1:cov_dim, sep = ""))
        data_list[[k]] <- local_data
      }
      return(do.call(rbind, data_list))
    }
    
    
    # first, generate a synthetic dataset
    synthetic_data <- data.generation(K = K, # number of sites 
                                      site_size = site_size, # site size for the K sites
                                      cov_dim = cov_dim, # covariate dimension
                                      beta_star = true_beta)
    
    site_names <- unique(synthetic_data$site)
    data_list <- as.list(rep(NA, length(site_names)))
    
    for(i in 1:length(site_names)){
      data_list[[i]] <- synthetic_data[synthetic_data$site == site_names[i], ]
      print(c(i, mean(data_list[[i]]$censor_ind)))
    }
    
    data_process <- function(data_list, covariate_names){
      # for each site, pre-calculate the failure time points, the risk sets, and the respective weights
      # also, remove those sites with zero events
      site_to_remove <- c()
      K <- length(data_list)
      failure_num <- rep(NA, K)
      failure_times <- as.list(rep(NA, K))
      risk_sets <- as.list(rep(NA, K))
      covariate_list <- as.list(rep(NA, K))
      failure_position <- as.list(rep(NA, K))
      for(k in 1:K){
        # prepare a list for covariates in matrix format so as to speed up computation of log partial likelihood, gradient, and hessian
        covariate_list[[k]] <- as.matrix(data_list[[k]][, covariate_names, drop = FALSE]) 
        # find over which position lies the failure times
        failure_position[[k]] <- which(data_list[[k]]$censor_ind == 1)
        # find failure times
        failure_times[[k]] <- data_list[[k]]$t2e[failure_position[[k]]]
        # the number of failures
        failure_num[k] <- length(failure_times[[k]])
        
        if(failure_num[k] == 0){
          site_to_remove <- c(site_to_remove, k)
        }else{
          temp_risk <- as.list(rep(NA, failure_num[k]))
          for(j in 1:failure_num[k]){
            temp_risk[[j]] <- which(data_list[[k]]$t2e >= failure_times[[k]][j])
          }
          risk_sets[[k]] <- temp_risk
        }
      }
      
      if(length(site_to_remove) > 0){
        data_list <- data_list[-site_to_remove]
        covariate_list <- covariate_list[-site_to_remove]
        failure_num <- failure_num[-site_to_remove]
        failure_times <- failure_times[-site_to_remove]
        failure_position <- failure_position[-site_to_remove]
        risk_sets <- risk_sets[-site_to_remove]
        K <- K - length(site_to_remove)
      }
      return(list(data_list = data_list,
                  covariate_list = covariate_list,
                  failure_position = failure_position,
                  failure_num = failure_num,
                  risk_sets = risk_sets,
                  K = K))
    }
    
    
    log_plk <- function(beta, covariate = NA, 
                        failure_position = NA,
                        failure_num = NA,
                        risk_sets = NA){
      
      eta <- drop(covariate %*% beta)
      res <- sum(eta[failure_position])
      
      exp_eta <- exp(eta)
      
      res - sum(vapply(risk_sets[seq_len(failure_num)],
                       function(idx) log(sum(exp_eta[idx])),
                       numeric(1)))
    }
    
    
    grad_plk <- function(beta, 
                         covariate = NA, 
                         failure_position = NA,
                         failure_num = NA,
                         risk_sets = NA){
      
      eta <- drop(covariate %*% beta)
      exp_eta <- exp(eta)
      
      # numerator part: sum of covariates at failures
      # always keep matrix to make colSums fast and safe
      res <- colSums(covariate[failure_position, , drop = FALSE])
      
      # subtract weighted mean covariates for each risk set
      for (j in seq_len(failure_num)) {
        idx <- risk_sets[[j]]
        if (length(idx) == 1L) {
          res <- res - covariate[idx, ]
        } else {
          w  <- exp_eta[idx]
          sw <- sum(w)
          # t(X_idx) %*% w  (p x 1), returned as numeric vector
          wx <- drop(crossprod(covariate[idx, , drop = FALSE], w))
          res <- res - wx / sw
        }
      }
      
      res
    }
    
    
    hess_plk <- function(beta,
                         p = NA,
                         covariate = NA, 
                         failure_num = NA,
                         risk_sets = NA){
      
      eta <- drop(covariate %*% beta)
      exp_eta <- exp(eta)
      
      res <- matrix(0.0, p, p)
      
      for (j in seq_len(failure_num)) {
        idx <- risk_sets[[j]]
        if (length(idx) > 1L) {
          w  <- exp_eta[idx]
          sw <- sum(w)
          
          Xidx <- covariate[idx, , drop = FALSE]
          
          # wx = sum_i w_i x_i  (p-vector)
          wx <- drop(crossprod(Xidx, w))
          
          # sum_i w_i x_i x_i^T  = crossprod( Xidx * sqrt(w) )
          Xw <- Xidx * sqrt(w)
          EXX <- crossprod(Xw) / sw
          
          # (sum w x)(sum w x)^T / (sum w)^2
          outer_term <- tcrossprod(wx) / (sw * sw)
          
          # your original form: outer_term - EXX  (negative covariance)
          res <- res + outer_term - EXX
        }
      }
      
      res
    }
    
    third_plk <- function(beta,
                          p,
                          covariate,
                          failure_num,
                          risk_sets) {
      eta <- drop(covariate %*% beta)
      exp_eta <- exp(eta)
      
      # third derivative tensor: p x p x p
      T3 <- array(0.0, dim = c(p, p, p))
      
      for (j in seq_len(failure_num)) {
        idx <- risk_sets[[j]]
        m <- length(idx)
        if (m <= 1L) next
        
        w <- exp_eta[idx]
        sw <- sum(w)
        prob <- w / sw  # softmax weights in this risk set
        
        X <- covariate[idx, , drop = FALSE]  # m x p
        
        # weighted mean mu (p-vector)
        mu <- drop(crossprod(prob, X))       # 1xp -> p
        
        # centered X
        Xc <- sweep(X, 2, mu, "-")           # m x p
        
        # Contribution of this risk set to ∇^3 log(sum exp) is E[(X-μ)^{⊗3}]
        # But for partial log-likelihood, we subtract it: T3 <- T3 - that
        for (k in seq_len(p)) {
          wk <- prob * Xc[, k]               # length m
          # crossprod: p x m  %*%  m x p  -> p x p
          # element (a,b) = sum_i Xc[i,a] * (Xc[i,b] * wk[i])
          Mk <- crossprod(Xc, Xc * wk)
          T3[, , k] <- T3[, , k] - Mk
        }
      }
      
      T3
    }
    
    mini_SL_fun <- function(beta, covariate = NA, 
                            failure_position = NA,
                            failure_num = NA,
                            risk_sets = NA,
                            hess_external = NA,
                            initial_beta = NA){
      
      res <- 0.5 * t(beta - initial_beta) %*% hess_external %*% (beta - initial_beta)
      res <- res + log_plk(beta, covariate = covariate,
                           failure_position = failure_position,
                           failure_num = failure_num,
                           risk_sets = risk_sets)
      return(res)
    }
    
    ODACH <- function(beta, covariate = NA, 
                      failure_position = NA,
                      failure_num = NA,
                      risk_sets = NA,
                      grad_external = NA,
                      hess_external = NA,
                      initial_beta = NA){
      res <- sum(grad_external*beta) + 0.5 * t(beta - initial_beta) %*% hess_external %*% (beta - initial_beta)
      res <- res + log_plk(beta, covariate = covariate,
                           failure_position = failure_position,
                           failure_num = failure_num,
                           risk_sets = risk_sets)
      return(res)
    }
    
    aug_SL <- function(beta, covariate = NA,
                       failure_position = NA,
                       failure_num = NA,
                       risk_sets = NA,
                       est_list = NA,
                       grad_list = NA,
                       hess_list = NA,
                       lead_site = NA){
      
      K <- length(est_list)
      idx <- setdiff(seq_len(K), lead_site)
      res <- 0
      for(int_i in idx){
        res <- res + 0.5 * t(beta - est_list[[int_i]]) %*% hess_list[[int_i]] %*% (beta - est_list[[int_i]]) + sum(grad_list[[int_i]] * (beta - est_list[[int_i]])) 
      }
      res <- c(res) + log_plk(beta, covariate = covariate,
                              failure_position = failure_position,
                              failure_num = failure_num,
                              risk_sets = risk_sets)
      return(res)
    }
    
    # T: array with dim (p, p, p)
    # v: length-p vector
    # returns: p x p matrix with M[j,k] = sum_l T[j,k,l] * v[l]
    contract_3rd <- function(T, v) {
      p <- dim(T)[1L]
      # unfold (j,k,l) into ((j,k), l)
      T_unf <- matrix(aperm(T, c(1,2,3)), nrow = p*p, ncol = p)
      M_vec <- drop(T_unf %*% v)           # length p*p
      matrix(M_vec, nrow = p, ncol = p)   # back to p x p
    }
    
    
    one_step_polish <- function(current_est, grad_list = NA, hess_list = NA, tensor_list = NA, est_list = NA,
                                coordination = "L", covariate = NA, failure_position = NA, failure_num = NA,
                                risk_sets = NA){
      effective_K <- length(est_list)
      cov_dim <- length(est_list[[2]])
      
      if(coordination == "L"){
        term1 <- hess_plk(beta = current_est, 
                          p = cov_dim,
                          covariate = covariate,
                          failure_num = failure_num,
                          risk_sets = risk_sets)
        
        term2 <- grad_plk(beta = current_est, 
                          covariate = covariate,
                          failure_position = failure_position,
                          failure_num = failure_num,
                          risk_sets = risk_sets)
        
        for (my_i in 2:effective_K) {
          delta <- current_est - est_list[[my_i]]
          
          Tm <- contract_3rd(tensor_list[[my_i]], delta)  # p x p
          
          Hi <- hess_list[[my_i]]
          gi <- grad_list[[my_i]]
          
          term1 <- term1 + Hi + Tm
          term2 <- term2 + gi + Hi %*% delta + 0.5 * (Tm %*% delta)
        }
        
      }else{
        term1 <- matrix(0, cov_dim, cov_dim)
        term2 <- rep(0, cov_dim)
        
        for (my_i in 1:effective_K) {
          delta <- current_est - est_list[[my_i]]
          
          Tm <- contract_3rd(tensor_list[[my_i]], delta)  # p x p
          
          Hi <- hess_list[[my_i]]
          
          term1 <- term1 + Hi + Tm
          term2 <- term2 + Hi %*% delta + 0.5 * (Tm %*% delta)
        }
      }
      
      OS_est <- c(current_est - solve(term1) %*% term2)
      return(OS_est)
    }
    
    
    
    pre_processing <- data_process(data_list, covariate_names = c("V1", "V2", "V3", "V4", "V5", "V6"))
    
    data_list <- pre_processing$data_list
    effective_K <- pre_processing$K
    
    pooled_df <- data_list[[1]]
    for(k in 2:effective_K){
      pooled_df <- rbind(pooled_df, data_list[[k]])
    }
    
    t0 <- proc.time()
    fit_pool <- coxph(Surv(t2e, censor_ind) ~ V1 + V2 + V3 + V4 + V5 + V6 + strata(site), data = pooled_df, method = "breslow")
    pool_est <- as.numeric(fit_pool$coefficients)
    opt_pool <- (proc.time() - t0)["elapsed"]
    
    ### proposed method coordinated by lead site
    time_L <- rep(NA, effective_K)
    time_L_OS <- rep(NA, effective_K)
    
    t0 <- proc.time()
    lead_est <- optim(par = rep(0, cov_dim), fn = log_plk, method = "L-BFGS-B", control = list(fnscale = -1),
                      covariate = pre_processing$covariate_list[[1]],
                      failure_position = pre_processing$failure_position[[1]],
                      failure_num = pre_processing$failure_num[[1]],
                      risk_sets = pre_processing$risk_sets[[1]], lower = lower_a, upper = upper_b)$par
    
    lead_hess <- hess_plk(beta = lead_est, 
                          p = cov_dim,
                          covariate = pre_processing$covariate_list[[1]],
                          failure_num = pre_processing$failure_num[[1]],
                          risk_sets = pre_processing$risk_sets[[1]])
    opt_L <- (proc.time() - t0)["elapsed"]
    
    mini_SL_list <- as.list(rep(NA, effective_K))
    grad_mini_SL <- as.list(rep(NA, effective_K))
    hess_mini_SL <- as.list(rep(NA, effective_K))
    tensor_mini_SL <- as.list(rep(NA, effective_K))
    
    for(k in 2:effective_K){
      t0 <- proc.time()
      mini_SL_list[[k]] <- optim(par = lead_est, fn = mini_SL_fun, 
                                 control = list(fnscale = -1), method = "L-BFGS-B",
                                 covariate = pre_processing$covariate_list[[k]],
                                 failure_position = pre_processing$failure_position[[k]],
                                 failure_num = pre_processing$failure_num[[k]],
                                 risk_sets = pre_processing$risk_sets[[k]],
                                 hess_external = lead_hess,
                                 initial_beta = lead_est, lower = lower_a, upper = upper_b)$par
      
      grad_mini_SL[[k]] <- grad_plk(beta = mini_SL_list[[k]],
                                    covariate = pre_processing$covariate_list[[k]],
                                    failure_position = pre_processing$failure_position[[k]],
                                    failure_num = pre_processing$failure_num[[k]],
                                    risk_sets = pre_processing$risk_sets[[k]])
      
      
      hess_mini_SL[[k]] <- hess_plk(beta = mini_SL_list[[k]],
                                    p = cov_dim,
                                    covariate = pre_processing$covariate_list[[k]],
                                    failure_num = pre_processing$failure_num[[k]],
                                    risk_sets = pre_processing$risk_sets[[k]])
      time_L[k] <- (proc.time() - t0)["elapsed"]
      
      t0 <- proc.time()
      tensor_mini_SL[[k]] <- third_plk(beta = mini_SL_list[[k]],
                                       p = cov_dim,
                                       covariate = pre_processing$covariate_list[[k]],
                                       failure_num = pre_processing$failure_num[[k]],
                                       risk_sets = pre_processing$risk_sets[[k]])
      time_L_OS[k] <- (proc.time() - t0)["elapsed"]
    }
    
    t0 <- proc.time()
    our_L <- optim(par = lead_est, fn = aug_SL, 
                   control = list(fnscale = -1), method = "L-BFGS-B",
                   covariate = pre_processing$covariate_list[[1]],
                   failure_position = pre_processing$failure_position[[1]],
                   failure_num = pre_processing$failure_num[[1]],
                   risk_sets = pre_processing$risk_sets[[1]],
                   grad_list = grad_mini_SL,
                   hess_list = hess_mini_SL,
                   est_list = mini_SL_list,
                   lead_site = 1, lower = lower_a, upper = upper_b)$par
    opt_L <- opt_L + (proc.time() - t0)["elapsed"]
    
    
    t0 <- proc.time()
    our_L_OS <- one_step_polish(current_est = our_L, grad_list = grad_mini_SL, hess_list = hess_mini_SL,
                                tensor_list = tensor_mini_SL, est_list = mini_SL_list, coordination = "L",
                                covariate = pre_processing$covariate_list[[1]],
                                failure_position = pre_processing$failure_position[[1]],
                                failure_num = pre_processing$failure_num[[1]],
                                risk_sets = pre_processing$risk_sets[[1]])
    opt_L_OS <- (proc.time() - t0)["elapsed"]
    
    
    
    ### proposed method coordinated by central server
    local_est <- as.list(rep(NA, effective_K))
    hess_local <- as.list(rep(NA, effective_K))
    tensor_local <- as.list(rep(NA, effective_K))
    time_C <- rep(NA, effective_K)
    time_C_OS <- rep(NA, effective_K)
    
    for(k in 1:effective_K){
      t0 <- proc.time()
      local_est[[k]] <- optim(par = rep(0, cov_dim), fn = log_plk, method = "L-BFGS-B", control = list(fnscale = -1),
                              covariate = pre_processing$covariate_list[[k]],
                              failure_position = pre_processing$failure_position[[k]],
                              failure_num = pre_processing$failure_num[[k]],
                              risk_sets = pre_processing$risk_sets[[k]], lower = lower_a, upper = upper_b)$par
      
      hess_local[[k]] <- hess_plk(beta = local_est[[k]], 
                                  p = cov_dim,
                                  covariate = pre_processing$covariate_list[[k]],
                                  failure_num = pre_processing$failure_num[[k]],
                                  risk_sets = pre_processing$risk_sets[[k]])
      time_C[k] <- (proc.time() - t0)["elapsed"]
      
      t0 <- proc.time()
      tensor_local[[k]] <- third_plk(beta = local_est[[k]], 
                                     p = cov_dim,
                                     covariate = pre_processing$covariate_list[[k]],
                                     failure_num = pre_processing$failure_num[[k]],
                                     risk_sets = pre_processing$risk_sets[[k]])
      time_C_OS[k] <- (proc.time() - t0)["elapsed"]
    }
    
    t0 <- proc.time()
    term1 <- matrix(0, cov_dim, cov_dim)
    term2 <- rep(0, cov_dim)
    for(my_k in 1:effective_K){
      term1 <- term1 + hess_local[[my_k]]
      term2 <- term2 + hess_local[[my_k]] %*% local_est[[my_k]]
    }
    our_C <- c(solve(term1) %*% term2)
    opt_C <- (proc.time() - t0)["elapsed"]
    
    
    t0 <- proc.time()
    our_C_OS <- one_step_polish(current_est = our_C, hess_list = hess_local, tensor_list = tensor_local, est_list =  local_est,
                                coordination = "C")
    opt_C_OS <- (proc.time() - t0)["elapsed"]
    
    
    
    
    ### ODACH
    local_est <- as.list(rep(NA, effective_K))
    local_var <- as.list(rep(NA, effective_K))
    time_ODACH1 <- rep(0, effective_K)
    for(k in 1:effective_K){
      t0 <- proc.time()
      fit_local <- coxph(Surv(t2e, censor_ind) ~ V1 + V2 + V3 + V4 + V5 + V6, data = data_list[[k]], method = "breslow")
      local_est[[k]] <- fit_local$coefficients
      local_var[[k]] <- fit_local$var
      time_ODACH1[k] <- (proc.time() - t0)["elapsed"]
    }
    
    opt_ODACH <- time_ODACH1[1]
    time_ODACH1[1] <- NA
    
    t0 <- proc.time()
    term1 <- rep(0, cov_dim)
    term2 <- matrix(0, cov_dim, cov_dim)
    for(k in 1:effective_K){
      term1 <- term1 + solve(local_var[[k]]) %*% local_est[[k]]
      term2 <- term2 + solve(local_var[[k]])
    }
    meta_est <- c(solve(term2) %*% term1) 
    opt_ODACH <- opt_ODACH + (proc.time() - t0)["elapsed"]
    
    
    
    grad_meta <- as.list(rep(NA, effective_K))
    hess_meta <- as.list(rep(NA, effective_K))
    time_ODACH2 <- rep(NA, effective_K)
    for(k in 2:effective_K){
      t0 <- proc.time()
      grad_meta[[k]] <- grad_plk(beta = meta_est, 
                                 covariate = pre_processing$covariate_list[[k]],
                                 failure_position = pre_processing$failure_position[[k]],
                                 failure_num = pre_processing$failure_num[[k]],
                                 risk_sets = pre_processing$risk_sets[[k]])
      
      
      hess_meta[[k]] <- hess_plk(beta = meta_est, 
                                 p = cov_dim,
                                 covariate = pre_processing$covariate_list[[k]],
                                 failure_num = pre_processing$failure_num[[k]],
                                 risk_sets = pre_processing$risk_sets[[k]])
      
      time_ODACH2[k] <- (proc.time() - t0)["elapsed"]
    }
    
    t0 <- proc.time()
    odach_est <- optim(par = meta_est, fn = ODACH, control = list(fnscale = -1), method = "L-BFGS-B",
                       covariate = pre_processing$covariate_list[[1]],
                       failure_position = pre_processing$failure_position[[1]],
                       failure_num = pre_processing$failure_num[[1]],
                       risk_sets = pre_processing$risk_sets[[1]],
                       grad_external = Reduce(`+`, grad_meta[-1]),
                       hess_external = Reduce(`+`, hess_meta[-1]),
                       initial_beta = meta_est, lower = lower_a, upper = upper_b)$par
    opt_ODACH <- opt_ODACH + (proc.time() - t0)["elapsed"]
    
    
    
    ###one-round ODACH
    t0 <- proc.time()
    fit_local <- coxph(Surv(t2e, censor_ind) ~ V1 + V2 + V3 + V4 + V5 + V6, data = data_list[[1]], method = "breslow")
    lead_est <- fit_local$coefficients
    opt_breve <- (proc.time() - t0)["elapsed"]
    
    grad_lead <- as.list(rep(NA, effective_K))
    hess_lead <- as.list(rep(NA, effective_K))
    time_breve <- rep(NA, effective_K)
    for(k in 2:effective_K){
      t0 <- proc.time()
      grad_lead[[k]] <- grad_plk(beta = lead_est, 
                                 covariate = pre_processing$covariate_list[[k]],
                                 failure_position = pre_processing$failure_position[[k]],
                                 failure_num = pre_processing$failure_num[[k]],
                                 risk_sets = pre_processing$risk_sets[[k]])
      
      
      hess_lead[[k]] <- hess_plk(beta = lead_est, 
                                 p = cov_dim,
                                 covariate = pre_processing$covariate_list[[k]],
                                 failure_num = pre_processing$failure_num[[k]],
                                 risk_sets = pre_processing$risk_sets[[k]])
      
      time_breve[k] <- (proc.time() - t0)["elapsed"]
    }
    
    
    t0 <- proc.time()
    breve_est <- suppressWarnings(tryCatch(
      {
        # ---- first try: BFGS ----
        optim(par = lead_est,
              fn = ODACH,
              control = list(fnscale = -1),
              method = "L-BFGS-B",
              covariate = pre_processing$covariate_list[[1]],
              failure_position = pre_processing$failure_position[[1]],
              failure_num = pre_processing$failure_num[[1]],
              risk_sets = pre_processing$risk_sets[[1]],
              grad_external = Reduce(`+`, grad_lead[-1]),
              hess_external = Reduce(`+`, hess_lead[-1]),
              initial_beta = lead_est, lower = lower_a, upper = upper_b)$par
      },
      error = function(e1) {
        # ---- fallback: Nelder–Mead ----
        rep(NA_real_, cov_dim)
      }
    )
    )
    opt_breve <- opt_breve + (proc.time() - t0)["elapsed"]
    
    
    final_res <- list(pool_est, odach_est, breve_est, 
                      our_L, our_L_OS, our_C, our_C_OS, 
                      time_L, opt_L, time_L_OS, opt_L_OS, 
                      time_C, opt_C, time_C_OS, opt_C_OS,
                      time_ODACH1, time_ODACH2, opt_ODACH,
                      time_breve, opt_breve, opt_pool)
    return(final_res)
  }
  res <- try(my_simulation_procedure(iter), silent = TRUE)
  return(res)
}



# run the main function in parallel
clnum <- 2 #cores_in_parallel
cl <- makeCluster(getOption("cl.cores", clnum))
# collect the simulation results
simu_res <- parLapply(cl, 1:MC_repli,  simulation)
stopCluster(cl)

# save(simu_res, file = "Cox_rho5.rdata")

cov_dim <- 6
true_beta <- c(0.35, -0.65, 0.35, 0.16, -0.14, -0.6)
est_mat <- array(NA, dim = c(length(simu_res), 7, cov_dim))
DTP_mat <- array(NA, dim = c(length(simu_res), 6, cov_dim))

our_L <- c()
our_L_OS <- c()
our_C <- c()
our_C_OS <- c()
breve <- c()
ODACH <- c()
pool <- c()

null_idx <- c()
bound_idx <- c()
for(i in 1:length(simu_res)){
  temp_res <- simu_res[[i]]
  if(length(temp_res) > 1){
    if(max(abs(temp_res[[3]])) == 5){
      bound_idx <- c(bound_idx, i)
    }
    for(j in 1:cov_dim){
      a1 <- temp_res[[1]][j]
      a2 <- temp_res[[2]][j]
      a3 <- temp_res[[3]][j]
      a4 <- temp_res[[4]][j]
      a5 <- temp_res[[5]][j]
      a6 <- temp_res[[6]][j]
      a7 <- temp_res[[7]][j]
      est_mat[i, , j] <- c(a1, a2, a3, a4, a5, a6, a7)
      DTP_mat[i, , j] <- (est_mat[i, -1, j] - est_mat[i, 1, j])^2
    }
    our_L <- c(our_L, sum(temp_res[[8]][-1]) + temp_res[[9]] )
    our_L_OS <- c(our_L_OS, sum(temp_res[[8]][-1] + temp_res[[10]][-1]) + temp_res[[9]] + temp_res[[11]])
    our_C <- c(our_C, sum(temp_res[[12]]) + temp_res[[13]])
    our_C_OS <- c(our_C_OS, sum(temp_res[[12]] + temp_res[[14]]) + temp_res[[13]] + temp_res[[15]])
    ODACH <- c(ODACH, sum(temp_res[[16]][-1]) + sum(temp_res[[17]][-1]) + temp_res[[18]])
    breve <- c(breve, sum(temp_res[[19]][-1]) + temp_res[[20]])
    pool <- c(pool, temp_res[[21]])
  }else{
    null_idx <- c(null_idx, i)
  }
  
}
if(length(null_idx) > 1){
  est_mat <- est_mat[-null_idx, , ]
  DTP_mat <- DTP_mat[-null_idx, , ]
}

bound_idx <- c(null_idx, bound_idx)


bias_mat <- matrix(NA, cov_dim, 7)
sd_mat <- matrix(NA, cov_dim, 7)
MSE_mat <- matrix(NA, cov_dim, 7)
for(i in 1:cov_dim){
  bias_mat[i, ] <- apply(est_mat[, , i] - true_beta[i], MARGIN = 2, mean)
  sd_mat[i, ] <- apply(est_mat[, , i], MARGIN = 2, sd)
  MSE_mat[i, ] <- apply((est_mat[, , i] - true_beta[i])^2, MARGIN = 2, mean)
}

for(i in 1:cov_dim){
  bias_mat[i, 3] <- mean(est_mat[-bound_idx, 3, i] - true_beta[i]) #apply(, MARGIN = 2, mean)
  sd_mat[i, 3] <- sd(est_mat[-bound_idx, 3, i]) #apply(est_mat[-bound_idx, 3, i], MARGIN = 2, sd)
  MSE_mat[i, 3] <- mean((est_mat[-bound_idx, 3, i] - true_beta[i])^2)#apply((est_mat[-bound_idx, 3, i] - true_beta[i])^2, MARGIN = 2, mean)
}

my_res <- rbind(bias_mat[1, ], sd_mat[1, ], MSE_mat[1, ],
                bias_mat[2, ], sd_mat[2, ], MSE_mat[2, ],
                bias_mat[3, ], sd_mat[3, ], MSE_mat[3, ],
                bias_mat[4, ], sd_mat[4, ], MSE_mat[4, ],
                bias_mat[5, ], sd_mat[5, ], MSE_mat[5, ],
                bias_mat[6, ], sd_mat[6, ], MSE_mat[6, ],
                apply(bias_mat, MARGIN = 2, mean),
                apply(sd_mat, MARGIN = 2, mean),
                apply(MSE_mat, MARGIN = 2, mean),
                c(mean(pool), mean(ODACH), mean(breve), 
                  mean(our_L), mean(our_L_OS),
                  mean(our_C), mean(our_C_OS)))

my_res[1:21, ] <- my_res[1:21, ] * 100 


xtab <- xtable(my_res, digits = 3)
print(xtab, include.rownames = FALSE)

